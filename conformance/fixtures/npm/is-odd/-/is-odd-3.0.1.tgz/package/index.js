module.exports = n => n % 2 === 1;
