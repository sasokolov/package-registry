module.exports = { scoped: true };
