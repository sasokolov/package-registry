module.exports = 'malicious payload';
