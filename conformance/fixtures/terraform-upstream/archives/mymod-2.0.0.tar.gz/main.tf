variable "name" { default = "mymod 2.0.0" }
output "version" { value = "2.0.0" }
