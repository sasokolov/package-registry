variable "name" { default = "mymod 1.0.0" }
output "version" { value = "1.0.0" }
