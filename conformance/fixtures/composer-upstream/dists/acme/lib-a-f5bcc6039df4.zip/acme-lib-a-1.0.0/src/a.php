<?php
function acme_a() { return 'a'; }
