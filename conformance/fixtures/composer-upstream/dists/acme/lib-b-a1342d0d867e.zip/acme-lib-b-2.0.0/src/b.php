<?php
function acme_b() { return 'b'; }
